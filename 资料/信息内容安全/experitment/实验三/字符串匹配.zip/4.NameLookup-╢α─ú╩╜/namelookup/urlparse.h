/*****************************************************************
*author:     xudongliang
*copyright:  www.pact518.hit.edu.cn
*date:       2014.01.02
*
*****************************************************************/
#ifndef _URL_PARSE_H_
#define _URL_PARSE_H_




int urlparse(char str[][30],char *url);











#endif
